document.querySelector('.btn').addEventListener('click', () => {
  alert('Button clicked! SCSS partials are working.');
});
