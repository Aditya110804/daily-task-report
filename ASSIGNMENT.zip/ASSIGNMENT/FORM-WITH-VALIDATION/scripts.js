const form = document.getElementById('registrationForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');

function validateName() {
    const nameError = document.getElementById('nameError');
    if (nameInput.value.trim() === '') {
        nameError.textContent = 'Name is required';
        nameInput.classList.add('error');
        return false;
    }
    nameError.textContent = '';
    nameInput.classList.remove('error');
    return true;
}

function validateEmail() {
    const emailError = document.getElementById('emailError');
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    if (emailInput.value.trim() === '') {
        emailError.textContent = 'Email is required';
        emailInput.classList.add('error');
        return false;
    } else if (!emailPattern.test(emailInput.value)) {
        emailError.textContent = 'Please enter a valid email';
        emailInput.classList.add('error');
        return false;
    }
    emailError.textContent = '';
    emailInput.classList.remove('error');
    return true;
}

function validatePassword() {
    const passwordError = document.getElementById('passwordError');
    
    if (passwordInput.value.trim() === '') {
        passwordError.textContent = 'Password is required';
        passwordInput.classList.add('error');
        return false;
    } else if (passwordInput.value.length < 6) {
        passwordError.textContent = 'Password must be at least 6 characters';
        passwordInput.classList.add('error');
        return false;
    }
    passwordError.textContent = '';
    passwordInput.classList.remove('error');
    return true;
}

form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const isNameValid = validateName();
    const isEmailValid = validateEmail();
    const isPasswordValid = validatePassword();
    
    if (isNameValid && isEmailValid && isPasswordValid) {
        alert('Form submitted successfully!');
        form.reset();
    }
});

nameInput.addEventListener('blur', validateName);
emailInput.addEventListener('blur', validateEmail);
passwordInput.addEventListener('blur', validatePassword);