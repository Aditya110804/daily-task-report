// DOM elements
const modal = document.getElementById('modal');
const modalImage = document.getElementById('modalImage');
const thumbnails = document.querySelectorAll('.thumbnail');
const closeBtn = document.querySelector('.close');

// Open modal function
function openModal(imageSrc, imageAlt) {
    modalImage.src = imageSrc.replace('300/200', '800/600'); // Get higher resolution
    modalImage.alt = imageAlt;
    modal.classList.add('show');
    document.body.style.overflow = 'hidden'; // Prevent scrolling
}

// Close modal function
function closeModal() {
    modal.classList.remove('show');
    document.body.style.overflow = 'auto'; // Restore scrolling
}

// Add click event to thumbnails
thumbnails.forEach(thumbnail => {
    thumbnail.addEventListener('click', () => {
        openModal(thumbnail.src, thumbnail.alt);
    });
});

// Close modal events
closeBtn.addEventListener('click', closeModal);

// Close modal when clicking outside image
modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        closeModal();
    }
});

// Close modal with Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('show')) {
        closeModal();
    }
});