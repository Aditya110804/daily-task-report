const taskInput = document.getElementById('taskInput');
const addBtn = document.getElementById('addBtn');
const taskList = document.getElementById('taskList');

function addTask() {
    const taskText = taskInput.value.trim();
    if (taskText === '') return;

    const li = document.createElement('li');
    li.innerHTML = `
        <input type="checkbox" onchange="toggleComplete(this)">
        <span>${taskText}</span>
        <button class="deleteBtn" onclick="deleteTask(this)">Delete</button>
    `;
    
    taskList.appendChild(li);
    taskInput.value = '';
}

function toggleComplete(checkbox) {
    checkbox.parentElement.classList.toggle('completed');
}

function deleteTask(button) {
    button.parentElement.remove();
}

addBtn.addEventListener('click', addTask);
taskInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTask();
});